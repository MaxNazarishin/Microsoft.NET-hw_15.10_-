﻿namespace PersonDLL
{
    public class Person
    {
        protected string name;
        protected string surname;
        protected int age;
        protected string phone;

        public string Name
        {
            get => name;
            set => name = value;
        }

        public string Surname
        {
            get => surname;
            set => surname = value;
        }

        public int Age
        {
            get => age;
            set => age = value;
        }

        public string Phone
        {
            get => phone;
            set => phone = value;
        }

        public Person() { }

        public Person(string name, string surname, int age, string phone)
        {
            this.name = name;
            this.surname = surname;
            this.age = age;
            this.phone = phone;
        }

        public virtual void Print()
        {
            Console.WriteLine($"Name: {name}, Surname: {surname}, Age: {age}, Phone: {phone}");
        }
    }
}
