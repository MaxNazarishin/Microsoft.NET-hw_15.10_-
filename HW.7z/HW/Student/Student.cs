﻿using PersonDLL;

namespace StudentDLL
{
    public class Student : Person
    {
        protected double average;
        protected int number_of_group;

        public double Average
        {
            get => average;
            set => average = value;
        }

        public int NumberOfGroup
        {
            get => number_of_group;
            set => number_of_group = value;
        }

        public Student() { }

        public Student(string name, string surname, int age, string phone, double average, int number_of_group)
            : base(name, surname, age, phone)
        {
            this.average = average;
            this.number_of_group = number_of_group;
        }

        public override void Print()
        {
            base.Print();
            Console.WriteLine($"Average: {average}, Group Number: {number_of_group}");
        }
    }
}
