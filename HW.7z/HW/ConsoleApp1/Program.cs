﻿using System;
using AcademyGroupDLL;
using StudentDLL;

namespace StudentGroupApp
{
    class Program
    {
        static void Main(string[] args)
        {
            AcademyGroup group = new AcademyGroup();
            bool exit = false;

            while (!exit)
            {
                try
                {
                    Console.WriteLine("Menu:");
                    Console.WriteLine("1. Add student");
                    Console.WriteLine("2. Remove student");
                    Console.WriteLine("3. Print students");
                    Console.WriteLine("4. Exit");
                    Console.Write("Select an option: ");
                    string option = Console.ReadLine();

                    switch (option)
                    {
                        case "1":
                            Console.Write("Enter name: ");
                            string name = Console.ReadLine();
                            Console.Write("Enter surname: ");
                            string surname = Console.ReadLine();
                            Console.Write("Enter age: ");
                            int age = int.Parse(Console.ReadLine());
                            Console.Write("Enter phone: ");
                            string phone = Console.ReadLine();
                            Console.Write("Enter average grade: ");
                            double average = double.Parse(Console.ReadLine());
                            Console.Write("Enter group number: ");
                            int groupNumber = int.Parse(Console.ReadLine());

                            var student = new Student(name, surname, age, phone, average, groupNumber);
                            group.Add(student);
                            break;

                        case "2":
                            Console.Write("Enter surname of the student to remove: ");
                            string surnameToRemove = Console.ReadLine();
                            group.Remove(surnameToRemove);
                            break;

                        case "3":
                            Console.WriteLine("List of students from file:");
                            group.PrintFromFile();
                            break;

                        case "4":
                            exit = true;
                            break;

                        default:
                            Console.WriteLine("Invalid option, please try again.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }
            }
        }
    }
}
