﻿using StudentDLL;

namespace AcademyGroupDLL
{
    public class AcademyGroup
    {
        private Student[] students;
        private int count;
        private const string filePath = "students.txt";

        public AcademyGroup()
        {
            students = new Student[100];
            count = 0;
            Load();
        }

        public void Add(Student student)
        {
            for (int i = 0; i < count; i++)
            {
                if (students[i].Name.Equals(student.Name, StringComparison.OrdinalIgnoreCase) &&
                    students[i].Surname.Equals(student.Surname, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Student {student.Name} {student.Surname} already exists. Please use a different name.");
                    return;
                }
            }

            if (count < students.Length)
            {
                students[count] = student;
                count++;
                Save();
            }
            else
            {
                Console.WriteLine("Cannot add more students, group is full.");
            }
        }

        public void Remove(string surname)
        {
            bool found = false;

            for (int i = 0; i < count; i++)
            {
                if (students[i].Surname.Equals(surname, StringComparison.OrdinalIgnoreCase))
                {
                    found = true;
                    for (int j = i; j < count - 1; j++)
                    {
                        students[j] = students[j + 1];
                    }
                    students[count - 1] = null;
                    count--;
                    i--;
                    Console.WriteLine($"Student {surname} removed successfully.");
                }
            }

            if (!found)
            {
                Console.WriteLine($"Student with surname {surname} not found.");
            }

            Save();
        }

        public void PrintFromFile()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Data file not found.");
                return;
            }

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 6)
                    {
                        var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), int.Parse(parts[5]));
                        student.Print();
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine($"Invalid student data in file: {line}. Expected 6 parts but found {parts.Length}.");
                    }
                }
            }
        }

        private void Save()
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                for (int i = 0; i < count; i++)
                {
                    writer.WriteLine($"{students[i].Name},{students[i].Surname},{students[i].Age},{students[i].Phone},{students[i].Average},{students[i].NumberOfGroup}");
                }
            }
        }

        private void Load()
        {
            try
            {
                if (File.Exists(filePath))
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string line;

                        while ((line = reader.ReadLine()) != null)
                        {
                            var parts = line.Split(',');
                            if (parts.Length == 6)
                            {
                                try
                                {
                                    var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), int.Parse(parts[5]));
                                    Add(student);
                                }
                                catch (FormatException ex)
                                {
                                    Console.WriteLine($"Error parsing student data: {line}. Exception: {ex.Message}");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Skipping invalid student data: {line}. Expected 6 parts but found {parts.Length}.");
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Data file not found, starting with an empty group.");
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }
        }
    }
}
